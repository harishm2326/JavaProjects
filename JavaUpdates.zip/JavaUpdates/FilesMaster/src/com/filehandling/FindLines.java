package com.filehandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FindLines {
	public static void main(String[] args) throws IOException {
		File f = new File("C:\\Users\\mandadi.harish\\OneDrive - Mphasis\\Desktop\\TXT files\\Dummy\\Dum.txt");
		int count = 0;
		FileReader Fr = new FileReader(f);
		BufferedReader br = new BufferedReader(Fr);
		while (br.readLine() != null){
			count++;
		}
		System.out.println("Number of lines in the file: " + count);
	}

}
