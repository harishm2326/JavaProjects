package com.filehandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderHandling {
	
	public static void main(String[] args) throws IOException {
		
		File file = new File("./Sample.txt");
		if (!file.exists());
		file.createNewFile();
		
		FileReader fr = new FileReader(file);
	}

}
