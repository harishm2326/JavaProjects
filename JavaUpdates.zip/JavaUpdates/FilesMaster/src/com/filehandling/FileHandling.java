package com.filehandling;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

public class FileHandling {
	
	public static void main(String[] args) throws IOException {
		File  f = new File("C:\\Users\\mandadi.harish\\OneDrive - Mphasis\\Desktop\\TXT files");
		//System.out.println(Arrays.toString(f.list()));
	
		
		f.createNewFile();
//		f.exists();
//		System.out.println(f.exists());
		
	}

}
