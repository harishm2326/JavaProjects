package com.filehandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class ScannerHandling {
	
	public static void main(String[] args) throws IOException {
		
		File file = new File("./Sample.txt");
		if (!file.exists());
		file.createNewFile();
		
		Scanner scanner = new Scanner(file);
		while (scanner.hasNextLine()) {
			System.out.println(scanner.nextLine());
		}
		
		
	}

}
