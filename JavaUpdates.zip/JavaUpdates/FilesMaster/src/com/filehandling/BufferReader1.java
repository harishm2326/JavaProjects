package com.filehandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

public class BufferReader1 {
	
	public static void main(String[] args) throws IOException {
		
		File file = new File("./Sample.txt");
		if (!file.exists());
		file.createNewFile();
		
		
		FileReader fr = new FileReader(file);
		
		BufferedReader br = new BufferedReader(fr);
		
		
		
		int asciicode ;
			}
		
	}

