package com.filehandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FindLines2 {
	public static void main(String[] args) throws IOException {
		File f = new File("C:\\Users\\mandadi.harish\\OneDrive - Mphasis\\Desktop\\TXT files\\Dummy\\Dum.txt");
		String ll = "";
		int ml = 0;
		FileReader Fr = new FileReader(f);
		BufferedReader br = new BufferedReader(Fr);
		String line;
		while ((line = br.readLine()) != null) {
			if (line.length() > ml) {
				ml = line.length();
				ll = line;
			}
		}
		System.out.println("Number of lines in the file: " + ll);
	}

}
