package com.filehandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class FileInputStreamfile {
	
	public static void main(String[] args) throws IOException {
		
		File file = new File("./Sample.txt");
		if (!file.exists());
		file.createNewFile();
		
		
		FileInputStream fis = new FileInputStream(file);
		int asciicode ;
		while((asciicode = fis.read())!=-1) {
			System.out.print((char)asciicode);
		}
		
	}

}
