package com.abstractionexample;

public abstract class function {
  
	abstract void trunon();
	abstract void trunoff();
}
