package com.abstractionexample;

public class remote extends function{

	@Override
	void trunon() {
		System.out.println("TV turn on");
		
	}

	@Override
	void trunoff() {
		System.out.println("TV turn off");
		
	}
 
	
}
