package com.abstractionexample;

public class TV {
 public static void main(String[] args) {
	remote r = new remote();
	r.trunoff();
	r.trunon();
}
}
