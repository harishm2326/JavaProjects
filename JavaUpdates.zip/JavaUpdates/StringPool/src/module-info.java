/**
 * 
 */
/**
 * 
 */
module StringPool {
}