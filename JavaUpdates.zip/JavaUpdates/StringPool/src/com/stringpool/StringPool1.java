package com.stringpool;

public class StringPool1 {
	public static void main(String[] args) {
		String s1 = "Hello";
		String s2 = "Hello";
		String s4 = new String("Hello");
		String s5 = new String("Hello").intern();
		
		System.out.println(s4.equals(s5));

	}

}


//S1 data stored in string pool
//S2 data first it will check the data of the S2 is same or if it is same it will return the S1 data.
//S4 data it will create the object in the heap memory
//S5 it uses the inter() method to forcefully add in the string pool
