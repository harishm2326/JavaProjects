package com.multi;

public class AddElementsInArray {
    public static void main(String[] args) {
        int[][] arr = {{1, 2, 1}, {9, 7, 2}, {6, 7, 4}};
        int[][] arr1 = {{2, 6, 8}, {0, 1, 3}, {1, 2, 4}};
        
        int[][] sumArray = new int[arr.length][arr[0].length];
        
        int i = 0; // Row index
        for (int[] row : arr) {
            int j = 0; // Column index
            for (int element : row) {
                sumArray[i][j] = element + arr1[i][j];
                j++;
            }
            i++;
        }
        
        System.out.println("The sum of the two arrays is:");
        for (int[] row : sumArray) {
            for (int element : row) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
    }
}
