package com.single;

public class SumOfnumbers {
	public static void main(String[] args) {
		int[] i = {2,5,1,9,6};
		int sum = 0;
            for(int numbers : i) {
            	sum += numbers;
            }
            System.out.println(sum);
	}
}
