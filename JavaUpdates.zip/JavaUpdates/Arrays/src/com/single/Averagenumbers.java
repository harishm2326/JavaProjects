package com.single;

public class Averagenumbers {
	public static void main(String[] args) {
		int[] i = {2,5,3,9,6};
		int sum =0;
		for(int number : i) {
			sum += number;
		}
		int average = (int) sum/ i.length;
		System.out.println(average);
	}
}
