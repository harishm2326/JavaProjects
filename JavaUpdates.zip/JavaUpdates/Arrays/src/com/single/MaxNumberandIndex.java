package com.single;

public class MaxNumberandIndex{

    public static void main(String[] args) {
        // Define the input array
        int[] numbers = {2, 5, 1, 9, 6};
        
        // Initialize max number and index
        int maxNumber = numbers[0];
        int maxIndex = 0;
        
        // Loop through the array to find the max number and its index
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > maxNumber) {
                maxNumber = numbers[i];
                maxIndex = i;
            }
        }
        
        // Print the result
        System.out.println("The maximum number in the array is: " + maxNumber);
        System.out.println("The index of the maximum number is: " + maxIndex);
    }
}
