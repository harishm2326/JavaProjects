package com.pojopackage;

public class Employee {

	//rules for POJO
	//Why we are usind POJO if we need to add multiple employee details we can use this class as data type..(like non primitive)
	//it should not implements interface
	//it should not extends any class
	//it must have getters and setters
	//All variable should be private
	
	//rules for Java BEAN class   -> It will usefful in enterprise aapplications
	//similar to pojo 
	//Rules :
		//must have non arg constructor
		//It should implement serializable class
		//it should not extends any class
		//it must have getters and setters
		//All variable should be private
	
	private int id ;
	private String name;
	private double salary;
	
	public void setID(int id) {
		this.id=id;
	}
	public int getID() {
		return id;
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
}
