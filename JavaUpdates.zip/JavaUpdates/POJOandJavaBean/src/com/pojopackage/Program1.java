package com.pojopackage;

public class Program1 {
  public static void main(String[] args) {
	Employee e1 = new Employee();

	//by creating object we will set the value and get the data
	e1.setID(123);
	e1.setName("Harish");
	e1.setSalary(45678.00);
	
	System.out.println(e1.getID());
	
	Employee e2 = new Employee();
	e2.setID(1234);
	e2.setName("Chowdary");
	e2.setSalary(43378.00);
	System.out.println(e2.getID());
	
	Employee e3 = new Employee();
	e3.setID(114);
	e3.setName("Bro");
	e3.setSalary(50078.00);
	System.out.println(e3.getID());
	
	Employee[] employee = new Employee[] {e1, e2, e3};
	double salary =  0.0;
	
	for (Employee emp : employee) {
        System.out.println("ID: " + emp.getID());
        System.out.println("Name: " + emp.getName());
        System.out.println("Salary: " + emp.getSalary());
        salary += emp.getSalary();
        System.out.println();
    }
	System.out.println("Total Salary of all employees: " + salary);
}
}


