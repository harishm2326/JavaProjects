package com.switchcase;

import java.util.*;
public class Switchcase {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter a number?");
		int number = scanner.nextInt();
		int result = number%2;

        switch(number) {
        case 0:
        	System.out.println("given is an even number" );
        break;
        case 1:
        	System.out.println("given is an odd number" );
        break;
        
        default :
        System.out.println("given is an odd number" );
        break;
        }





//		if (number % 2 == 0) {
//			System.out.println("given is an even number" );
//		}
//		else {
//			System.out.println("given is an odd number" );
//
//		}

	}
}


