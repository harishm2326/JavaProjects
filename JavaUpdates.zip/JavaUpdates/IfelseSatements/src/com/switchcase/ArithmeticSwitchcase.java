package com.switchcase;

import java.util.Scanner;

public class ArithmeticSwitchcase {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter first number");
		double a = scanner.nextDouble(); 

		System.out.println("Enter Second number");
		double b = scanner.nextDouble();

		System.out.println("Enter operations = '+', '-' , '*', '/', '%'");

		char operators = scanner.next().charAt(0);

		switch (operators) {
		case '+': System.out.println("Result: " + (a + b)); 
		break;
		case '-': System.out.println("Result: " + (a - b)); 
		break;
		}



		}
	}
