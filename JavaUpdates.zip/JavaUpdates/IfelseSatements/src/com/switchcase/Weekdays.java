package com.switchcase;

import java.time.MonthDay;
import java.util.Scanner;

public class Weekdays {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the day");
		String day = scanner.nextLine().toLowerCase();
		switch (day) {
		case "monday" :
		case "tuesday" :
		case "friday" :
		case "wednesday" :
		case "thursday" :
		System.out.println("it is week day");
		break;
		default:
		System.out.println("it is weekend day");

		}
	}
}
