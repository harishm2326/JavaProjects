package com.encapsulation;

public class Aniaml {

	public static void main(String[] args) {
		Dog dog = new Dog();
		dog.setAge(2);
		dog.setName("Harish");
		
		System.out.println(dog.getAge() + " " + dog.getName());
		System.out.println(dog.getName());
	}
}
