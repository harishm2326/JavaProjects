package com.encapsulation;

public class Teacher {
public static void main(String[] args) {
	Student s = new Student(101);
	
	s.setAttendence(true);
	s.getAttendence();
	s.setName("Harish");
	System.out.println("Name is:" +  s.getName());

	
}
}
