package com.encapsulation;

public class Student {
	
	private int rollNo;
	private String name;
	private boolean Attendence;


	public Student(int rollNo) {
		this.rollNo = rollNo;
	}
	
	public void setAttendence(boolean flag) {
		Attendence = flag;
		System.out.println("Assigned");
	}
	public boolean getAttendence() {
		System.out.println("good");
		return Attendence;
		
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
