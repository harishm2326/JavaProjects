package com.countthecharacters;

import java.util.Scanner;

public class FindLettersSpecial {
public static void main(String[] args) {
	
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter a value : ");
	String word = scanner.nextLine();
	
	int Uppercase =0;
	int Lowercase =0;
	int Digits =0;
	int SpecialCharcters=0;
	
	for (int i =0;i<word.length();i++) {
		char ch = word.charAt(i);
		
		if (Character.isUpperCase(ch)) {
			Uppercase++;
		}else if(Character.isLowerCase(ch)) {
			Lowercase++;
		}else if(Character.isDigit(ch)) {
			Digits++;
		}else {
			SpecialCharcters++;
		}
	}
	System.out.println("UpperCase = " + Uppercase);
	System.out.println("LowerCase = " + Lowercase);
	System.out.println("Digits = " + Digits);
	System.out.println("SpecialCharcters = " + SpecialCharcters);
}
}