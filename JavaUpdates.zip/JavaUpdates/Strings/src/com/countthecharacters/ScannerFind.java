	package com.countthecharacters;

	import java.util.Scanner;

	public class ScannerFind {
	    public static void main(String[] args) {
	       String word = "Awertyu@#$%^1234";
	        
	        var Uppercase = 0;
	        int Lowercase = 0;
	        int Digits = 0;
	        int SpecialCharacters = 0;
	        
	        for (int i = 0; i < word.length(); i++) {
	            char ch = word.charAt(i);
	            
	            if (Character.isUpperCase(ch)) {
	                Uppercase++;
	            } else if (Character.isLowerCase(ch)) {
	                Lowercase++;
	            } else if (Character.isDigit(ch)) {
	                Digits++;
	            } else {
	                SpecialCharacters++;
	            }
	        }
	        
	        System.out.println("Uppercase letters: " + Uppercase);
	        System.out.println("Lowercase letters: " + Lowercase);
	        System.out.println("Digits: " + Digits);
	        System.out.println("Special characters: " + SpecialCharacters);
	        
	        // Close the scanner
	    }
	}

