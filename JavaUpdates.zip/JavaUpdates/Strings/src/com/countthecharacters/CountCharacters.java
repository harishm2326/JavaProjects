package com.countthecharacters;

public class CountCharacters {
public static void main(String[] args) {
	String S1 = "   hello world  ";
//	char target ='l';
//	int count =0;
//	for (int i = 0; i < S1.length(); i++) {
//		 if (S1.charAt(i) == target) {
//			count++;
//		}
//		}
//		
//	System.out.println(target + ": " + count);
//	}
//	
//}


//String S1 = "Java is Super";
//String reversed = "";
//for(int i = S1.length()-1; i>=0; i-- ){
//	reversed += S1.charAt(i);
//	
//}
//System.out.println(reversed);

System.out.println(S1.trim());
String[] words=S1.split(" ");
//int count = words.length;
//System.out.println(count);
	}
	
}