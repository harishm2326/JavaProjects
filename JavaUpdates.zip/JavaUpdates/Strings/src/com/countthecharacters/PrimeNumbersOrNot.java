package com.countthecharacters;

import java.util.Scanner;

public class PrimeNumbersOrNot {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter");
		int a =sc.nextInt();
		int count = 0;
		
		for(int i=1; i<=a; i++) {
			if(a % i == 0) {
				count++;
			}
		}
		
		if(count==2) {
		System.out.println("Prime");
		}
		else {
		System.out.println("Not Prime");
		}
	}
}



//--- 1 2 3 4 5 6 7
//=0, count of =0 should be 2
//it is prime 