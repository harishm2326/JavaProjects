package com.countthecharacters;

public class ChangeWordstoUppercase {
 public static void main(String[] args) {
	String input = "This is a test String!!";
	        String[] words = input.split(" "); // Split the input string into words

	        for (int i = 0; i < words.length; i++) {
	            if ((i + 1) % 2 != 0) { // Odd index (1-based)
	                words[i] = words[i].toUpperCase();
	            } else { // Even index (1-based)
	                words[i] = new StringBuilder(words[i]).reverse().toString();
	            }
	        }

	        // Join the modified words back into a single string
	        String result = String.join(" ", words);

	        // Print the result
	        System.out.println(result);
	    }
	}

