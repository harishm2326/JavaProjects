package com.ListInterface;

import java.util.*;
public class VectorListtoconvert_array_to_Listy {

	public static void main(String[] args) {

		//Below one is array
		Integer[] arr = new Integer[] {1, 2, 3, 4, 5};
		//To convert above array to list
		Vector<Integer> v1 = new Vector<>(Arrays.asList(arr)); //To convert from array to list
		//Generics <> - to stop the different types of datatypes adding in array

		//v1.add("Harish");

		int sum =0;

		for(int i=0; i<v1.size();i++) {
			sum += (Integer) v1.get(i);
		}
		System.out.println(sum);		

	}

}
