package com.ListInterface;

import java.util.*;
public class VectorList {
  
	
	//Vector is a class 
    //when we create the object of that class
    //it will create one array by default capacity of 10;
	
	public static void main(String[] args) {
		Vector v1 = new Vector() ;
		v1.add("Harish");
		v1.add("h");
		v1.add("a");
		v1.add("r");
		v1.add("Harish");
		v1.add("h");
		v1.add("a");
		v1.add("r");
		v1.add("Harish");
		v1.add("h");
		v1.add("a");
		v1.add("r");
        
		
		
		System.out.println(v1);
		System.out.println(v1.size());
		System.out.println(v1.capacity());
	}
}
