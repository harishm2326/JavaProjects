package com.ListInterface;

import java.util.*;
public class ArrayList1 {
	public static void main(String[] args) {
		ArrayList<Integer> al1 = new ArrayList<>();
		
		al1.add(0);
		al1.add(1);
		al1.add(2);
		al1.add(3);
		al1.add(4);
		al1.add(0);
		al1.add(1);
		al1.add(2);
		al1.add(3);
		al1.add(4);
		al1.add(0);
		al1.add(1);
		al1.add(2);
		al1.add(3);
		al1.add(4);
		al1.add(16);
		
		System.out.println(al1);
		System.out.println(al1.size());
		
	}

}
