package com.ListInterface;
import java.util.*;
public class LinkedList1 {

	public static void main(String[] args) {
		ArrayList<String> al =new ArrayList<>();
		al.add("s1");
		al.add("s2");
		LinkedList<String> ll = new LinkedList<>();
		
		ll.add("Harish");
		ll.add("H1");
		ll.add("H2");
		ll.add("H3");
		ll.add("H4");
		ll.add(1, null);
		ll.addAll(al);
		System.out.println(ll);
		
	}
}
