package com.examples;

import java.util.Stack;

public class MergeList {
public static void main(String[] args) {
	Stack<Integer> s1 = new Stack<>();
	s1.add(4);
	s1.add(9);
	s1.add(8);
	Stack<Integer> s2 = new Stack<>();
	s2.add(5);
	s2.add(0);
	s2.add(10);
	
	System.out.println(s1);
	System.out.println(s2);
	
	s1.addAll(s2);
	System.out.println(s1);
}
}
