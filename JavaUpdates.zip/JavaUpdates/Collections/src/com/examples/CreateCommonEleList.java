package com.examples;

import java.util.Vector;

public class CreateCommonEleList {

	public static void main(String[] args) {
		Vector<Integer> v = new Vector<Integer>();
		v.add(4);
        v.add(9);
        v.add(8);
        v.add(5);
        Vector<Integer> v1 = new Vector<Integer>();
        v1.add(1);
        v1.add(8);
        v1.add(0);
        v1.add(5);
        v1.add(1);
        v1.add(6);
        
        System.out.println(v);
        System.out.println(v1);
        Vector<Integer> v3 = new Vector<Integer>();
        
        for(int i =0; i<v.size();i++) {
        	if (v1.contains(v.get(i)) && !v3.contains(v.get(i))) {
                v3.add(v.get(i));
		}
        }System.out.println(v3);
	}
}

