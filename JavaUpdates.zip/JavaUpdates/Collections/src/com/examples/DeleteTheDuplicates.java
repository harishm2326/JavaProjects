package com.examples;

import java.util.LinkedList;

public class DeleteTheDuplicates {
    public static void main(String[] args) {
        LinkedList<Integer> ll = new LinkedList<>();
        ll.add(7);
        ll.add(2);
        ll.add(4);
        ll.add(2);
        ll.add(6);
        ll.add(2);
        ll.add(0);
        System.out.println("Original List: " + ll);

        // Call the method to remove duplicates
        removeDuplicates(ll);
        System.out.println("List after removing duplicates: " + ll);
    }

    public static void removeDuplicates(LinkedList<Integer> list) {
        for (int i = 0; i < list.size(); i++) {
            int currentElement = list.get(i);
            boolean isDuplicate = false;
            for (int j = 0; j < list.size(); j++) {
                if (i != j && currentElement == list.get(j)) {
                    list.remove(j);
                    j--; // adjust index after removal
                    isDuplicate = true;
                }
            }
            if (isDuplicate) {
                list.remove(i);
                i--; // adjust index after removal
            }
        }
    }
}
