package com.examples;
 
import java.util.*;
 
public class HighestDuplicatenumber {
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		{
	        List<Integer> l1 = new ArrayList<>();
	        l1.add(5);
	        l1.add(80);
	        l1.add(5);
	        l1.add(6);
	        l1.add(90);
	        l1.add(4);
	        l1.add(5);
	        l1.add(5);
	        l1.add(7);
	        l1.add(7);
 
	        System.out.println("List: " + l1);
	        
	        //int highestDuplicate = Integer.MIN_VALUE;
	        int highestDuplicate=0;
	        int highestCount = 0;
 
	        for (int i = 0; i < l1.size(); i++) {
	            int count = 0;
	            for (int j = 0; j < l1.size(); j++) {
	                if (l1.get(i).equals(l1.get(j))) {
	                    count++;
	                }
	            }
 
	            if (count > highestCount || (count == highestCount && l1.get(i) > highestDuplicate)) {
	                highestCount = count;
	                highestDuplicate = l1.get(i);
	            }
	        }
 
	        if (highestCount > 1) {
	            System.out.println("Element with the highest duplicates: " + highestDuplicate);
	            System.out.println("Count of that element: " + highestCount);
	        } else {
	            System.out.println("No duplicates found");
	        }
		}
	}
}
 