package com.examples;
import java.util.*;
public class SpliTheArray {
   public static void main(String[] args) {
	LinkedList<Integer> ll = new LinkedList<>();
	ll.add(4);
	ll.add(9);
	ll.add(8);
	ll.add(5);
	ll.add(0);
	ll.add(10);
	
	System.out.println(ll);
	LinkedList<Integer> l1 = new LinkedList<>();
	LinkedList<Integer> l2 = new LinkedList<>();
	int split = ll.size() / 2;
	
	for(int i =0; i<split; i++) {
		l1.add(ll.get(i));
		
	}System.out.println(l1);
	
	for(int i =split; i<ll.size(); i++) {
		l2.add(ll.get(i));
		
	}System.out.println(l2);
	
}
}
