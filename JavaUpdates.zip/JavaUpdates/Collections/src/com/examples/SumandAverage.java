package com.examples;
import java.util.*;
public class SumandAverage {

	public static void main(String[] args) {
		Vector<Integer> v = new Vector<>();
		v.add(4);
		v.add(5);
		v.add(0);
		v.add(9);
		v.add(8);
		v.add(10);

		System.out.println(v);
		
		int sum =0;
		for(int i=0; i<v.size(); i++) {
			sum += v.get(i);
		}
		double average = sum/v.size();
		System.out.println(sum);
		System.out.println(average);
		
		
	}

}
