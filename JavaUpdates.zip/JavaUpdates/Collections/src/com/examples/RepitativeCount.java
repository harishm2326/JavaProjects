package com.examples;

import java.util.Vector;

public class RepitativeCount {

	public static void main(String[] args) {
		//First list which contains all the elements
	
		Vector<String> v = new Vector<>();
		v.add("baby");
		v.add("ball");
		v.add("soap");
		v.add("baby");
		v.add("shampoo");
		v.add("chalk");
		v.add("soap");
		v.add("make");
		v.add("baby");
		v.add("lotion");
		
		System.out.println(v);
		//Second list which contains all the unique elements
		Vector<String> v1 = new Vector<>();
		 for (int i = 0; i < v.size(); i++) {
	            int count = 0;
	            if (!v1.contains(v.get(i))) {
	            	//Duplicates will store here
	                for (int j = 0; j < v.size(); j++) {
	                    if (v.get(i).equals(v.get(j))) {
	                        count++;
	                    }
	                    
	                }if (count > 1) {
                        System.out.println("Element: " + v.get(i) + ", Count: " + count);
                    }v1.add(v.get(i));
		
		}
		 }
	}
}
