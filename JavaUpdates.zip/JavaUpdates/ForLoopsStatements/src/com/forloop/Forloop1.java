package com.forloop;

public class Forloop1 {

	public static void main(String[] args) {
		int i;
		for(i=1;i<=100;i++) {
			System.out.println(i);
		}

	}

}
