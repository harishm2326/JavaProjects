package com.forloop;

public class EvenNumbersforloop {

	public static void main(String[] args) {
		int start = 200;
		int end = 500;
		for (int i = start; i<=end ; i++) {
			if (i%2==0) {
				System.out.println(i);
			}
		}

	}

}
