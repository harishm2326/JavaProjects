package com.ExceptionHandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class FileNotFound {

    public static void main(String[] args) {
        // Define a file that does not exist
        File file = new File("C:\\Users\\mandadi.harish\\Downloads\\Hello.txt");

        try { // Attempt to open the nonexistent file with FileInputStream 
        	FileReader fis = new FileReader(file); 
        	}
        catch (FileNotFoundException e) 
        { // Handle the FileNotFoundException
        	System.out.println("File not found ");
        	e.printStackTrace();
        	
        }
    }
}
