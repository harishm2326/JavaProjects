package com.ExceptionHandling;

public class ThrowKeyWord {

	public static void main(String[] args) {
		
		int a = 25;
		int b = 45;
		if (a > b) {
			System.out.println("All Good");		
		}
		else {
			throw new ArithmeticException("Not Good");
		}
		
	}

}
