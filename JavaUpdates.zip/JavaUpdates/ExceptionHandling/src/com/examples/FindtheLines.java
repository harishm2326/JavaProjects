package com.examples;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FindtheLines {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		
		File file = new File("C:\\Users\\mandadi.harish\\OneDrive - Mphasis\\Desktop\\TXT files\\Dummy.txt");
		if (!file.exists());
		file.createNewFile();
		
		int linecount =0;
		
		try (FileInputStream fis = new FileInputStream(file)){
			int byteread;
			while ((byteread = fis.read()) != -1) {
				if(byteread=='\n'){
					linecount++;
					
				}
				
			}
			
		}catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Number of lines in the file: " + linecount);
	}
}
