package dolooping;

public class Test3 {

	public static void main(String[] args) {
	
		
		int i = 150;
		
		while (i<=200) {
			if (i%7==0) {
				System.out.println(i);
			}
			i++;
		}
		

	}

}
