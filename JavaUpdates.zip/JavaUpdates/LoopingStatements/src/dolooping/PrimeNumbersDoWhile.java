package dolooping;

public class PrimeNumbersDoWhile {

	public static void main(String[] args) {
		int a = 50;  // Starting range
		int b = 150; // Ending range
        int i = a;
        
        System.out.println("Below are the numbers for prime form " + a + " to " + b);
        
      do  {
    	  if (isPrime(i)) {
         	 System.out.println(i);
         }
    	  i++;	
      }
      while (i<=b);      	  
   
	}
    private static boolean isPrime(int number) {
    	if (number <=1 ) {
    		return false;
    	}
    		for(int i = 2; i <= Math.sqrt(number);i++) {
    			if (number % i == 0) {
    				return false;
    			}
    		}			
		return true;
		
}
}