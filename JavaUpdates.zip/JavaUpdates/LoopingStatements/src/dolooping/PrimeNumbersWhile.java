package dolooping;

public class PrimeNumbersWhile {

	public static void main(String[] args) {
		int a = 50;  // Starting range
		int b = 150; // Ending range
		int i = a;
		System.out.println("Below are the prime numbers ");
		
		while (i<b) {
			if (isPrime(i)) {
				System.out.println(i);
			}
			
			i++;
		}
}

	private static boolean isPrime(int number) {
		if(number <= 1) {
			return false;
		}
		for(int i = 2; i <= Math.sqrt(number); i ++) {
			if(number % i == 0) {
				return false;
			}
		}
	
		return true;
	}
}