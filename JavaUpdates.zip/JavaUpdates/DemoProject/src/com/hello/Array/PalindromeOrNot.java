package com.hello.Array;

public class PalindromeOrNot {
	public static void main(String[] args) {
		int abc = 987789;
		
		System.out.println(abc+ " " + isPalindrome(abc));

}

	public static boolean isPalindrome(int number) {
	    int originalNumber = number;
	    int reversedNumber = 0;

	    while (number != 0) {
	        int digit = number % 10;
	        reversedNumber = reversedNumber * 10 + digit;
	        number /= 10;
	    }

	    return originalNumber == reversedNumber;
	}
}