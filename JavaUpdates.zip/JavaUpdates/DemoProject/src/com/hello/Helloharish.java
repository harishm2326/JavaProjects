package com.hello;

import java.util.Scanner;

public class Helloharish {

	 int a =2;
	 int b = 5;
//	 int c = a + b ;
//	 static int d = ++a + a++;
//	 static int e = ++a + a++;
	public static void main(String[] args) {
//	Helloharish helloharish = new Helloharish();
//		Scanner scanner = new Scanner(System.in)  ;
//		Student student = new Student();
//		System.out.println(helloharish.c);
//		System.out.println("what is your name ? ");
//		String name = scanner.nextLine();
//		System.out.println(student.getName());
//		System.out.println("what is your employee number ? ");
//		int employee = scanner.nextInt();
//		System.out.println("This is your employee number = " + employee);
//		System.out.println(e);
//	scanner.close();
		
		 int a =12;
		 int b = 13;
		 
		 if (a<b)  {
		 System.out.println("a less than b");
		 
		  if (a==b){
			 System.out.println("a greater than b");
		 }
		 }
		 else {
			 System.out.println("a equals to b");
		 }
		  
		
	}

}
