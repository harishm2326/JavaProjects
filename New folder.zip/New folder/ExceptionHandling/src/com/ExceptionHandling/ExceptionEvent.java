package com.ExceptionHandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ExceptionEvent {

	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("Executrion started");



		int a = 5;
		int b = 0;
		int result;

		File file = new File("C:\\Users\\mandadi.harish\\Downloads\\v1rates.txt");
		FileInputStream file1 = new FileInputStream(file);
		System.out.println(file);
		try {


			result = a/b;
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("Final blocked caokoklled");
		}

		finally {
			System.out.println("Final blocked called");
		}
	}
}
