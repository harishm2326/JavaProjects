package dolooping;

public class EvenNumbersUsingLoops {

	public static void main(String[] args) {
		int start = 40;
		int end = 80;
		int sum = 0;
		int i = start;
		while (i<=end) {
			if (i%2 == 0) {
				sum += i;
			}
			i++;
		}
		System.out.println(sum);
	}
}
