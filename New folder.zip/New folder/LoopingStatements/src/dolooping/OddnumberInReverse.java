package dolooping;

public class OddnumberInReverse {

    public static void main(String[] args) {
        int start = 25;
        int end = 200;
        int i = end; // Initialize i with the end value

        System.out.println("Odd numbers in reverse order from " + end + " to " + start + ":");

        while (i >= start) {
            if (i % 2 != 0) { // Check if the number is odd
                System.out.println(i);
            }
            i--; // Decrement the number
        }
    }
}
