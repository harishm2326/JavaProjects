package com.evenorodd;

import java.time.MonthDay;
import java.util.Scanner;

public class Weekdays {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the day");
		String day = scanner.nextLine();
		if (day.equalsIgnoreCase("Monday")) {
			System.out.println("Weekday");
		}else if (day.equalsIgnoreCase("Tuesday")) {
			System.out.println("Weekday");
		}
		else if (day.equalsIgnoreCase("Tuesday")) {
			System.out.println("Weekday");
		}else   {
			System.out.println("Weekend");
		}
	}

}
