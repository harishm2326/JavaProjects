package com.evenorodd;

import java.util.*;


public class EvenorOdd {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		try {
		System.out.println("Enter a number?");
		 int number = scanner.nextInt();
		 if (number % 2 == 0) {
			 System.out.println("given is an even number" );
		 }
		 else {
			 System.out.println("given is an odd number" );
			 
		 }
		 
		}catch (InputMismatchException e) { System.out.println("Invalid input. Please enter an integer.");{
		}
		}
	}
}
		 

