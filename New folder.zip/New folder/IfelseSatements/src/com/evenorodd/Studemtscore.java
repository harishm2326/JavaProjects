package com.evenorodd;

import java.util.Scanner;

public class Studemtscore {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter the marks");
		int marks = scanner.nextInt();
		if (marks < 35 ) {
			System.out.println("You are failed");
		}
		else if (marks == 35 ) {
				System.out.println("You are pass");
		}else if (marks < 70 ) {
			System.out.println("You are third class");
		}else if (marks < 85 ) {
			System.out.println("You are second class");
	} else if (marks > 85 ) {
		System.out.println("You are topper of the class");
} 
	}
}
	
