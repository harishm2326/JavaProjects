package com.forloop;

public class Divisibleby7forloop {

	public static void main(String[] args) {
		int start = 150;
		int end = 200;
		for (int i = start; i<=end ; i++) {
			if (i%7==0) {
				System.out.println(i);
			}
		}

	}

}
