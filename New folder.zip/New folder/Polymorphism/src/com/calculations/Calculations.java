package com.calculations;

public class Calculations {

	public void add(int a, int b) {
		int sum = a + b;
		System.out.println(sum);
	}
	public void add(int a, int b, int c) {
		int sum1 = a + b + c;
		System.out.println(sum1);
	}
	
	public static void main(String[] args) {
	    Calculations c = new Calculations();
		c.add(2, 3);
		c.add(2, 3, 9);
		
	}
}
