package com.single;

public class MergedArray {
	public static void main(String[] args) {
	    
	        String[] array1 = {"chai","coffee"};
	        String[] array2 = {"milk","water","coke"};
	        
	  
	        String[] mergedArray = new String[array1.length + array2.length];
	        
	     
	        for (int i = 0; i < array1.length; i++) {
	            mergedArray[i] = array1[i];
	        }
	        
	        // Copy elements from the second array
	        for (int i = 0; i < array2.length; i++) {
	            mergedArray[array1.length + i] = array2[i];
	        }
	        
	        // Print the merged array
	        System.out.print("Merged array: ");
	        for (String i : mergedArray) {
	            System.out.print(i+" ");
	        }
	    }
	}

