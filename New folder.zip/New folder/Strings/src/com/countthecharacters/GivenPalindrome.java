package com.countthecharacters;

public class GivenPalindrome {

}
